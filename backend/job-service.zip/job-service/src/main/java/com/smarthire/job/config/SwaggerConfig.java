package com.smarthire.job.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI customOpenAPI() {

        return new OpenAPI()
                .info(
                        new Info()
                                .title("Smart Hire Application Service API")
                                .version("1.0")
                                .description(
                                        "Application and Recruiter Dashboard APIs"
                                )
                );
    }
}